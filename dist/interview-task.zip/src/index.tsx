import React from 'react';
import ReactDOM from 'react-dom';
import {Requirements} from './requirements/Requirements';
import './global.css';
import './api/api';

ReactDOM.render(
  <React.StrictMode>
    <Requirements />
  </React.StrictMode>,
  document.getElementById('root')
);
