# Candidate notes

This is for your own personal use. The headings here are suggestions, though we are likely to ask about some of these. You can add as many as you like, but this document will not be checked into source control.

Assume the following features may be required in future. Think about what would be required and how you would approach implementing each feature, and what trade-offs there may be for any approaches you come up with.

### The API requires authentication

### The widgets list provides more items than the front end can display at once

### The widgets list should be sortable

### The widgets list API request is too slow, so we want to filter the list down before fetching it

### The widget detail page needs to show a chart

### The page needs to be viewed on devices of varying sizes, from mobile devices to 4K screens

### We need to display a list of doodads and a details page
- Only consider the additional requirements for creating the new page, rather than the specifics of what is to be displayed on the page. Take it that doodads will be accessed in a similar way, but we have yet to confirm what shape the data will be. 

### We need to migrate to a mobile app

### We want the information displayed on the page to be up to date whenever the page is viewed. This is to be automatic and seamless.